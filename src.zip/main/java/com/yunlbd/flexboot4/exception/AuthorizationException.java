package com.yunlbd.flexboot4.exception;

import org.springframework.security.access.AccessDeniedException;

/**
 * 权限校验异常
 * 继承自 AccessDeniedException，可被 GlobalExceptionHandler 和 RestAccessDeniedHandler 捕获
 */
public class AuthorizationException extends AccessDeniedException {

    public AuthorizationException(String msg) {
        super(msg);
    }

    public AuthorizationException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
