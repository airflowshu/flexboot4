package com.yunlbd.flexboot4.security.aspect;

import com.yunlbd.flexboot4.common.annotation.RequireAuthCode;
import com.yunlbd.flexboot4.common.util.SecurityUtils;
import com.yunlbd.flexboot4.controller.BaseController;
import com.yunlbd.flexboot4.exception.AuthorizationException;
import com.yunlbd.flexboot4.service.SysMenuService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;

import static com.yunlbd.flexboot4.common.constant.SysConstant.SYS_SUPER_USER_ID;

/**
 * 权限码验证切面
 * 拦截 @RequireAuthCode 注解，验证用户是否拥有相应权限
 */
@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class AuthCodeAspect {

    private final SysMenuService sysMenuService;

    @Around("@annotation(requireAuthCode)")
    public Object checkAuthCode(ProceedingJoinPoint joinPoint, RequireAuthCode requireAuthCode) throws Throwable {
        // 1. 获取方法信息
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();

        // 2. 获取当前用户ID
        String userId = SecurityUtils.getUserId();
        if (userId == null) {
            log.warn("User not authenticated when accessing method: {}", method.getName());
            throw new AuthorizationException("用户未登录");
        }

        // 3. 超级管理员豁免
        if (requireAuthCode.allowSuperAdmin() && SYS_SUPER_USER_ID.equals(userId)) {
            log.debug("Super admin user {} bypassed auth check for method: {}", userId, method.getName());
            return joinPoint.proceed();
        }

        // 4. 解析完整权限码
        String requiredAuthCode = resolveAuthCode(requireAuthCode, joinPoint.getTarget());
        if (requiredAuthCode == null || requiredAuthCode.isEmpty()) {
            log.error("Auth code not specified for method: {}", method.getName());
            throw new IllegalStateException("权限码配置错误");
        }

        // 5. 查询用户权限码列表（利用已有缓存）
        List<String> userAuthCodes = sysMenuService.getPermissionCodes(userId);

        // 6. 权限验证
        if (!userAuthCodes.contains(requiredAuthCode)) {
            log.warn("User {} lacks permission {} for method: {}",
                     userId, requiredAuthCode, method.getName());
            throw new AuthorizationException(
                String.format("权限不足，需要权限: %s", requiredAuthCode)
            );
        }

        log.debug("User {} passed auth check for {}", userId, requiredAuthCode);
        return joinPoint.proceed();
    }

    /**
     * 解析完整权限码
     * 优先级: value > prefix:suffix
     */
    private String resolveAuthCode(RequireAuthCode annotation, Object target) {
        // 优先使用value（完整权限码）
        if (!annotation.value().isEmpty()) {
            return annotation.value();
        }

        // 使用动态前缀 + suffix
        if (!annotation.suffix().isEmpty()) {
            // 如果是BaseController的子类，调用getAuthCodePrefix()获取前缀
            if (target instanceof BaseController) {
                try {
                    String prefix = ((BaseController<?, ?, ?>) target).getAuthCodePrefix();
                    if (prefix != null && !prefix.isEmpty()) {
                        return prefix + ":" + annotation.suffix();
                    }
                } catch (Exception e) {
                    log.error("Failed to get auth code prefix from BaseController", e);
                }
            }
        }

        return null;
    }
}
