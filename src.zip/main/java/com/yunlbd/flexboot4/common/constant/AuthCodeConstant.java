package com.yunlbd.flexboot4.common.constant;

/**
 * 权限码操作常量
 * 用于统一管理权限操作类型，避免硬编码
 */
public class AuthCodeConstant {

    // CRUD 基础操作
    public static final String OP_CREATE = "Create";
    public static final String OP_UPDATE = "Update";
    public static final String OP_DELETE = "Delete";
    public static final String OP_BATCH_DELETE = "BatchDelete";
    public static final String OP_QUERY = "Query";
    public static final String OP_EXPORT = "Export";
    public static final String OP_IMPORT = "Import";

    /**
     * 构建完整权限码
     * @param module 模块名
     * @param resource 资源名
     * @param operation 操作名
     * @return 完整权限码，如 "System:Menu:Create"
     */
    public static String buildAuthCode(String module, String resource, String operation) {
        return String.format("%s:%s:%s", module, resource, operation);
    }
}
