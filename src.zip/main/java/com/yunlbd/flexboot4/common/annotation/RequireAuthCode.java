package com.yunlbd.flexboot4.common.annotation;

import java.lang.annotation.*;

/**
 * 权限码校验注解
 * 用于方法级别的细粒度权限控制
 *
 * 使用示例：
 * 1. 固定权限码: @RequireAuthCode("System:Menu:Create")
 * 2. 动态前缀: @RequireAuthCode(suffix = "Create") + BaseController.getAuthCodePrefix()
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RequireAuthCode {

    /**
     * 完整权限码，如 "System:Menu:Create"
     * 优先级高于 suffix，如果设置了value则忽略suffix
     */
    String value() default "";

    /**
     * 权限码后缀，如 "Create", "Update", "Delete"
     * 需要配合 BaseController.getAuthCodePrefix() 使用
     * 例如: suffix="Create" + getAuthCodePrefix()="System:Menu" = "System:Menu:Create"
     */
    String suffix() default "";

    /**
     * 是否允许超级管理员(ID=1)无条件通过
     * 默认true
     */
    boolean allowSuperAdmin() default true;
}
